//
//  kmeans.h
//  Mothur
//
//  Created by SarahsWork on 12/4/13.
//  Copyright (c) 2013 Schloss Lab. All rights reserved.
//

#ifndef Mothur_kmeans_h
#define Mothur_kmeans_h

#include "communitytype.h"

/**************************************************************************************************/

class KMeans : public CommunityTypeFinder {
    
public:
    KMeans(vector<vector<int> >, int);
    
private:


};

/**************************************************************************************************/

#endif
